#ifndef __TEST_UDP_H__
#define __TEST_UDP_H__

#include "../lwip_check.h"

Suite* udp_suite(void);

#endif
